"""
This code implements the "Functional connectivity convolutional (FC-conv) network", 
which is a major network of the "Spatio-Temporal Directed Acyclic Graph Learning 
with Attention Mechanisms (ST-DAG-Att)" framework

The FC-conv network includes
 - FC-conv:         Functional connectivity convolution
 - FC-SAtt:         Functional connectivity based spatial attention
 - Output layer:    multi-layer MLP

May. 27, 2021  Created by Shih-Gu Huang

Copyright (C) 2021,





All rights reserved.
"""

import tensorflow as tf
import pandas as pd
from datetime import datetime


import numpy as np
import os, time, collections, shutil


from scipy import stats
from sklearn import metrics



class base_model(object):
    
    def __init__(self):
        self.regularizers = []
    
    # High-level interface which runs the constructed computational graph.
     
    def predict(self, data, labels=None, sess=None):
        """
        Run one prediction against the full epoch of data.
        sess: the session in which the model has been trained.
        data:        ST data,  N x T x n (number of samples x number of time points x number of nodes)
        labels:      real measures, N
        predictions: predicted measures, N
        """                    
        loss = 0
        N = data.shape[0]
        predictions = np.empty(N)
        sess = self._get_session(sess)
        for begin in range(0, N, self.batch_size):
            end = begin + self.batch_size
            end = min([end, N])
            
            batch_data = np.zeros((self.batch_size, data.shape[1]))   
            tmp_data = data[begin:end,:]                                           
            if type(tmp_data) is not np.ndarray:
                tmp_data = tmp_data.toarray()  # convert sparse matrices
            batch_data[:end-begin] = tmp_data     
            feed_dict = {self.ph_data: batch_data, self.ph_dropout: 1.0 , self.ph_is_training: False}     
            
            # Compute loss if labels are given.
            if labels is not None:
                if labels.ndim == 1:
                    batch_labels = np.zeros(self.batch_size)
                    batch_labels[:end-begin] = labels[begin:end]
                    feed_dict[self.ph_labels] = batch_labels
                    batch_pred, batch_loss = sess.run([self.op_prediction, self.op_loss], feed_dict)
                else:
                    batch_labels = np.zeros((self.batch_size, labels.shape[1]))
                    batch_labels[:end-begin,:] = labels[begin:end,:]
                    feed_dict[self.ph_labels] = batch_labels
                    batch_pred, batch_loss = sess.run([self.op_prediction, self.op_loss], feed_dict)
                    
                loss += batch_loss
            else:
                batch_pred = sess.run(self.op_prediction, feed_dict)
                
            predictions[begin:end] = batch_pred[:end-begin]     
        if labels is not None:
            return predictions, loss * self.batch_size / N       
        else:
            return predictions            
        
     
        
    def evaluate(self, data, labels, sess=None):
        """
        Run one evaluation against the full epoch of data.
        Return the precision and the number of correct predictions.
        Batch evaluation saves memory and enables this to run on smaller GPUs.
        sess: the session in which the model has been trained.
        data:        ST data,  N x T x n (number of samples x number of time points x number of nodes)
        labels:      real measures, N
        predictions: predicted measures, N
        loss:        MSE + regularization
        mse, mae, corr, pval:  evaluation metrices
        """
        t_process, t_wall = time.process_time(), time.time() # version Python 3
#        t_process, t_wall = time.clock(), time.time() # version Python 2
        predictions, loss = self.predict(data, labels, sess)             

        mse = metrics.mean_squared_error(labels, predictions)    
        mae = metrics.mean_absolute_error(labels, predictions)
        corr, pval = stats.pearsonr(labels, predictions)

        string = 'loss: {:.2f} '.format(loss)
        if sess is None:
            string += '\ntime: {:.0f}s (wall {:.0f}s)'.format(time.process_time()-t_process, time.time()-t_wall)    
        return string, loss, predictions, mse, mae, corr, pval



    def fit(self, train_data, train_labels,  val_data, val_labels, \
            learning_rate, num_epochs, decay_steps, finetune=False, finetune_fc=False):
        """
        fit the model using training and validation sets
        train_data: training ST data,  N1 x T x n (number of training samples x number of time points x number of nodes)
        train_labels: training labels, N1
        val_data: validation ST data,  N2 x T x n (number of validation samples x number of time points x number of nodes)
        val_labels: validation labels, N2     
        val_loss_list, val_mse_list,  val_mae_list,  val_corr_list, val_pval_list: list of validation loss and metrices
        """              
        config=tf.ConfigProto(allow_soft_placement=True, log_device_placement=True)  
        config.gpu_options.per_process_gpu_memory_fraction=0.9 # set the portion of memory used
        sess = tf.Session(graph=self.graph, config=config)        
        sess.run(self.op_init)
        
        ckpt = tf.train.get_checkpoint_state(self._get_path('checkpoints'))
       
        # Load the latest model
        if finetune:
            # Restore from check point
            shutil.copytree(self._get_path('checkpoints'), self._get_path('checkpoints_orig')) # keep a copy of the pretrained model
            path = os.path.join(self._get_path('checkpoints'), 'model')
            self.op_saver.restore(sess, ckpt.model_checkpoint_path)
            self.learning_rate = learning_rate
            self.num_epochs = num_epochs
            self.decay_steps = decay_steps
            self.finetune_fc = finetune_fc
        else:
            shutil.rmtree(self._get_path('summaries'), ignore_errors=True)
            shutil.rmtree(self._get_path('checkpoints'), ignore_errors=True)
            os.makedirs(self._get_path('checkpoints'))
            path = os.path.join(self._get_path('checkpoints'), 'model')
            self.finetune_fc = finetune_fc
       
        # Start the queue runners
        tf.train.start_queue_runners(sess = sess)
        writer = tf.summary.FileWriter(self._get_path('summaries'), self.graph)

        # Training.
        min_loss = 100000000.                                                    
        step_list = []                                                        
        train_loss_list = []                                                   
        train_mse_list = []
        train_mae_list = []
        train_corr_list = []
        train_pval_list = []     
        
        val_loss_list = []                                                            
        val_mse_list = []
        val_mae_list = []
        val_corr_list = []
        val_pval_list = []        
        
        indices = collections.deque()
        num_steps = int(self.num_epochs * train_data.shape[0] / self.batch_size)
        for step in range(1, num_steps+1):

            # Be sure to have used all the samples before using one a second time.
            if len(indices) < self.batch_size:
                indices.extend(np.random.permutation(train_data.shape[0]))
            idx = [indices.popleft() for i in range(self.batch_size)]
            batch_data, batch_labels = train_data[idx,:], train_labels[idx]  
                
            if type(batch_data) is not np.ndarray:
                batch_data = batch_data.toarray()  # convert sparse matrices

            feed_dict = {self.ph_data: batch_data, self.ph_labels: batch_labels, \
                         self.ph_dropout: self.dropout, self.ph_lr: self.learning_rate , self.ph_is_training: True}      
            learning_rate, loss_average = sess.run([self.op_train, self.op_loss_average], feed_dict)

      
            # Periodical evaluation of the model.
            if step % self.eval_frequency == 0 or step == num_steps or step == 1:
                epoch = step * self.batch_size / train_data.shape[0]
                start_time = time.time()

                # Check performance of the training set
                string, loss_train, predictions, mse_train, mae_train, corr_train, pval_train \
                =self.evaluate(train_data, train_labels, sess)
                
                step_list.append(step)
                train_loss_list.append(loss_train)
                train_mse_list.append(mse_train)
                train_mae_list.append(mae_train)
                train_corr_list.append(corr_train)
                train_pval_list.append(pval_train)                
                duration = time.time() - start_time
                
                train_summ = tf.Summary()
                train_summ.value.add(tag='train_loss', simple_value=loss_train)          
                train_summ.value.add(tag='train_mse', simple_value=mse_train)            
                train_summ.value.add(tag='train_mae', simple_value=mae_train)           
                train_summ.value.add(tag='train_corr', simple_value=corr_train)           
                train_summ.value.add(tag='train_pval', simple_value=pval_train)                           
                writer.add_summary(train_summ, step)
                writer.flush()
                
                # Check performance of the validation set
                string, loss_valid, predictions, mse_valid, mae_valid, corr_valid, pval_valid  \
                =self.evaluate(val_data, val_labels, sess)       
                
                val_loss_list.append(loss_valid)     
                val_mse_list.append(mse_valid)
                val_mae_list.append(mae_valid)
                val_corr_list.append(corr_valid)
                val_pval_list.append(pval_valid)                 
                
                valid_summ = tf.Summary()
                valid_summ.value.add(tag='valid_loss', simple_value=loss_valid)           
                valid_summ.value.add(tag='valid_mse', simple_value=mse_valid)           
                valid_summ.value.add(tag='valid_mae', simple_value=mae_valid)        
                valid_summ.value.add(tag='valid_corr', simple_value=corr_valid)        
                valid_summ.value.add(tag='valid_pval', simple_value=pval_valid)      
                writer.add_summary(valid_summ, step)
                writer.flush()
      
                num_examples_per_step = self.batch_size
                examples_per_sec = num_examples_per_step / duration
                sec_per_batch = float(duration)
     
                print('%s: ' % datetime.now())
                print('step: {} / {} (epoch: {:.2f} / {}):'.format(step, num_steps, int(epoch), self.num_epochs))
                print('learning_rate = {:.2e}, loss_average = {:.2e}'.format(learning_rate, loss_average))
                format_str = ('%.1f examples/sec; %.3f ' 'sec/batch')
                print(format_str % (examples_per_sec, sec_per_batch))
                print('Train loss = %.4f' % loss_train)
                print('Train MSE = %.4f' % mse_train)
                print('Train MAE = %.4f' % mae_train)
                print('Train corrrelation = %.4f' % corr_train)
                print('Train p-value = %.4f' % pval_train)                

                print('Validation loss = %.4f' % loss_valid)
                print('Validation MSE = %.4f' % mse_valid)
                print('Validation MAE = %.4f' % mae_valid)
                print('Validation corrrelation = %.4f' % corr_valid)
                print('Validation p-value = %.4f' % pval_valid)                   
                print('----------------------------')
      
                # Save the training and validation performance for every step
                df = pd.DataFrame(data={'step':step_list, 'train_loss':train_loss_list, 'train_mse': train_mse_list,  
                                        'train_mae': train_mae_list,  'train_corr': train_corr_list, 'train_pval': train_pval_list, 
                                        'val_loss': val_loss_list,  'val_mse': val_mse_list,  'val_mae': val_mae_list,  
                                        'val_corr': val_corr_list, 'val_pval': val_pval_list })  
                df.to_csv(self._get_path('') + 'performance_trainvalid.csv')  
    
            # Save the model (checkpoint) with the largest adjusted gmean (for future evaluation) 
            string, loss_valid, predictions, mse_valid, mae_valid, corr_valid, pval_valid  = \
            self.evaluate(val_data, val_labels, sess)  
            loss_valid_new = loss_valid
            if loss_valid_new < min_loss:    
                min_loss = loss_valid_new            
                self.op_saver.save(sess, path, write_state=True, global_step=step)

        print('Validation loss: Smallest = {:.2f}, Mean = {:.2f}'.format(min(val_loss_list), np.mean(val_loss_list[-10:])))            
        writer.close()
        sess.close()       
        return val_loss_list, val_mse_list,  val_mae_list,  val_corr_list, val_pval_list      



    def get_var(self, name):
        """ read variable value"""
        sess = self._get_session()
        var = self.graph.get_tensor_by_name(name + ':0')
        val = sess.run(var)
        sess.close()
        return val


    def build_graph(self, T0, C):
        """
        Build the computational graph of the network model.
        T0: number of time points of input data
        n0: number of nodes of input data
        C: number of prediction measures
        """
        self.graph = tf.Graph()
        with self.graph.as_default():

            # Inputs.
            with tf.name_scope('inputs'):
                self.ph_data = tf.placeholder(tf.float32, (self.batch_size, T0), 'data')           
                if C == 1:
                    self.ph_labels = tf.placeholder(tf.float32, (self.batch_size), 'labels')
                    self.ph_labels2 = tf.placeholder(tf.float32, (self.batch_size), 'labels1')
                else:    
                    self.ph_labels = tf.placeholder(tf.float32, (self.batch_size, C), 'labels')
                    self.ph_labels2 = tf.placeholder(tf.float32, (self.batch_size, C), 'labels2')
                self.ph_dropout = tf.placeholder(tf.float32, (), 'dropout')
                self.ph_is_training = tf.placeholder(tf.bool, (), 'is_training')                          
                self.ph_lr = tf.placeholder(tf.float32, (), 'learning_rate')

            # Model.
            op_logits = self.inference(self.ph_data, self.ph_dropout, self.ph_is_training)
            self.op_loss, self.op_loss_average = self.loss_rmse(op_logits, self.ph_labels, self.regularization)
            self.op_train = self.training(self.op_loss, self.ph_lr,
                    self.decay_steps, self.decay_rate, self.momentum, self.finetune_fc) # changed for finetuning with different learning rate
            self.op_prediction = self.prediction(op_logits)

            # Initialize variables, i.e. weights and biases.
            self.op_init = tf.global_variables_initializer()
            
            # Summaries for TensorBoard and Save for model parameters.
            self.op_summary = tf.summary.merge_all()
            self.op_saver = tf.train.Saver(max_to_keep=5)
        
        self.graph.finalize()
    
    
    
    def inference(self, data, dropout, is_training):             
        """
        It builds the model, i.e. the computational graph, as far as
        is required for running the network forward to make predictions
        data:        ST data, N x T x n (number of samples x number of time points x number of nodes)
        dropout:     dropout rate
        is_training: model training mode
        """
        logits = self._inference(data, dropout, is_training)                     
        return logits
    
    

    def prediction(self, logits):
        """Return the predictions."""
        with tf.name_scope('prediction'):
            prediction = logits[:,0]                                                                                  
            return prediction



    def loss_rmse(self, y_pred, y, regularization):                           
        """Adds to the inference model the layers required to generate loss (RMSE)."""
        with tf.name_scope('loss_rmse'):
            with tf.name_scope('root_mean_squared_error'):
                y = tf.to_float(y)
                rmse = tf.sqrt(tf.reduce_mean(tf.square((y - y_pred[:,0]))))
                rmse = tf.Print(rmse, [rmse], message="Root mean squared error: ")
            with tf.name_scope('regularization'):
                l2_loss = tf.losses.get_regularization_loss()                
#                regularization *= tf.add_n(self.regularizers)       # if _weight_variable() or _bias_variable() is used
#                regularization += l2_loss
                regularization = l2_loss
                regularization = tf.Print(regularization, [regularization], message="regularization: ")
                
            loss = rmse + regularization                                     
            
            # Summaries for TensorBoard.
            tf.summary.scalar('loss/root_mean_squared_error', rmse)
            tf.summary.scalar('loss/regularization', regularization)
            tf.summary.scalar('loss/total', loss)
            with tf.name_scope('averages'):
                averages = tf.train.ExponentialMovingAverage(0.9)
                op_averages = averages.apply([rmse, regularization, loss])
                tf.summary.scalar('loss/avg/root_mean_squared_error', averages.average(rmse))
                tf.summary.scalar('loss/avg/regularization', averages.average(regularization))
                tf.summary.scalar('loss/avg/total', averages.average(loss))
                with tf.control_dependencies([op_averages]):
                    loss_average = tf.identity(averages.average(loss), name='control')
            return loss, loss_average


        
        
    def training(self, loss, learning_rate, decay_steps, decay_rate=0.95, momentum=0.9, finetune_fc=False):
        """Adds to the loss model the Ops required to generate and apply gradients."""
        with tf.name_scope('training'):
            # Learning rate.
            global_step = tf.Variable(0, name='global_step', trainable=False)
            print('Global step: ', tf.cast(global_step, np.int32))            
            print('Learning rate before decay: ', learning_rate)                    
            if decay_rate != 1:
                learning_rate = tf.train.exponential_decay(
                        learning_rate, global_step, decay_steps, decay_rate, staircase=True)
                              
            tf.summary.scalar('learning_rate', learning_rate)
            
            update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)  # for batch normalization
            with tf.control_dependencies(update_ops):
            # Optimizer.
                if momentum == 0:
                    optimizer = tf.train.GradientDescentOptimizer(learning_rate)
                else:
                    optimizer = tf.train.AdamOptimizer(learning_rate)
                
                if finetune_fc == True:                                                           
                    fc_vars = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, 'fc')
                    logits_vars = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, 'logits')
                    train_vars = []
                    train_vars.append(fc_vars)
                    train_vars.append(logits_vars)
                    print(train_vars)
                else:
                    train_vars = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES)
                    print(train_vars)

            with tf.control_dependencies(update_ops):
                grads = optimizer.compute_gradients(loss, var_list=train_vars)       

            with tf.control_dependencies(update_ops):                
                op_gradients = optimizer.apply_gradients(grads, global_step=global_step)

            # Histograms.
            for grad, var in grads:
                if grad is None:
                    print('warning: {} has no gradient'.format(var.op.name))
                else:
                    tf.summary.histogram(var.op.name + '/gradients', grad)
                                                   
            with tf.control_dependencies([op_gradients] + update_ops):
                op_train = tf.identity(learning_rate, name='control')

            return op_train



    def _get_path(self, folder):
        return os.path.join(self.dir_name, folder)

    
    
    def _get_session(self, sess=None):
        """Restore parameters if no session given."""
        if sess is None:
            sess = tf.Session(graph=self.graph)
            filename = tf.train.latest_checkpoint(self._get_path('checkpoints'))
            print('Checkpoint filename: ', filename)
            self.op_saver.restore(sess, filename)
        return sess



    def _weight_variable(self, shape, is_reg=True):
        """User-defined weight variables"""        
        initial = tf.truncated_normal_initializer(0, 0.1)
        var = tf.get_variable('weights', shape, tf.float32, initializer=initial)
        if is_reg:
            self.regularizers.append(tf.nn.l2_loss(var))
        tf.summary.histogram(var.op.name, var)
        return var



    def _bias_variable(self, shape, is_reg=True):
        """User-defined bias variables"""            
        initial = tf.constant_initializer(0.1)
        var = tf.get_variable('bias', shape, tf.float32, initializer=initial)
        if is_reg:
            self.regularizers.append(tf.nn.l2_loss(var))
        tf.summary.histogram(var.op.name, var)
        return var



class FCCNN(base_model):
    """
    Functional connectivity convolutional (FC-conv) network
    T0:   number of time points of input data
    n0:   number of nodes of input data    
    C:    number of prediction measures
        
    The following are hyper-parameters    
        CeCn:number of filters of EdgeConv and NodeConv in FC-conv
        r:   bottleneck ratio of MLP in FC-SAtt 
        M:   number of hidden neurons of fully connected layers in output prediction layer

    Training parameters:
        num_epochs:    Number of training epochs.
        learning_rate: Initial learning rate.
        decay_rate:    Base of exponential decay. No decay with 1.
        decay_steps:   Number of steps after which the learning rate decays.
        momentum:      Momentum. 0 indicates no momentum.
        is_training:   model training mode

    Regularization parameters:
        regularization: L2 regularizations of weights and biases.
        dropout:        Dropout in FC layers: probability to keep hidden neurons. No dropout with 1.
        batch_size:     Batch size. Must divide evenly into the dataset sizes.
        eval_frequency: Number of steps between evaluations.

    Directories:
        dir_name: Name for save directory (including summaries and model parameters).
    """


    def __init__(self, T0, C, CeCn, r, M,
                finetune=False, finetune_fc=False,
                num_epochs=10, learning_rate=0.001, decay_rate=0.95, decay_steps=20, momentum=0.9,
                regularization=0.001, dropout=0, batch_size=32, eval_frequency=20,
                dir_name='', decay_factor=0.1 , is_training='True'):   
        super().__init__() # version Python 3
#        super(stgcnn, self).__init__() # version Python 2
                      
        # Store attributes and bind operations.
        self.CeCn, self.r, self.M = CeCn, r, M       
        self.finetune = finetune
        self.finetune_fc = finetune_fc
        self.num_epochs, self.learning_rate = num_epochs, learning_rate
        self.regularization, self.dropout = regularization, dropout
        self.batch_size, self.eval_frequency = batch_size, eval_frequency
        self.dir_name = dir_name      

        self.decay_rate, self.momentum = decay_rate, momentum
        self.decay_factor = decay_factor
        
        if type(decay_steps) is list == True:
            self.decay_steps = decay_steps
        else:
            self.decay_steps = decay_steps
        
        print ('decay_steps = ', self.decay_steps)
        print ('dir_name = ', self.dir_name)
        
        # Build the computational graph.
        self.build_graph(T0, C)                                        
        


    
    def pearson(self, x):
        """ Pearson's correlation 
            Input:  N x T x n x Cin
            Output: (NxCin) x n x n
        """        
        N, T, n, Cin = x.get_shape()   
        N, T, n, Cin = int(N), int(T), int(n), int(Cin)

#        mu_x = tf.reduce_mean(x, axis=1, keepdims=True)
#        x = tf.subtract(x, mu_x)
# 
#        sd_x = tf.sqrt(tf.reduce_sum(tf.multiply(x,x), axis=1, keepdims=True)/float(T-1))                                           
#        x = tf.divide(x, sd_x)        

        x = tf.transpose(x, perm=[0, 3, 2, 1]) # N, Cin, n, T
        x = tf.reshape(x, [N*Cin, n, T])
#        x = tf.matmul(x, tf.transpose(x,[0,2,1]))
#        x = x/float(T-1)
        x = tf.linalg.set_diag(x,tf.zeros([N*Cin, n]))      # diagonal elements to be 0           
        x = tf.where(tf.is_nan(x), tf.zeros_like(x), x)     # avoid nan
        x = tf.where(tf.is_inf(x), tf.zeros_like(x), x)     # avoid inf                 
        return x
    
    

    def EdgeConv(self, x, Cout, reg, is_relu=True, is_reg=True):
        """ Edge convolution layer
            x:       input FC features, N x n x n x Cin
            Cout:    number of filters
            reg:     regularization rate
            is_reg:  whether uses regularization
            is_relu: whether uses leaky ReLU
            return:  output FC features, N x n x 1 x Cout
        """   
        n= int(x.get_shape()[1])
        if is_reg==True:           
            x = tf.layers.conv2d(inputs=x, filters=Cout, kernel_size=[1,n], 
                                  kernel_regularizer= tf.contrib.layers.l2_regularizer(scale=reg))         
        else:
            x = tf.layers.conv2d(inputs=x, filters=Cout, kernel_size=[1,n])                    
        return tf.nn.leaky_relu(x, alpha=0.33) if is_relu else x



    def NodeConv(self, x, Cout, reg, is_relu=True, is_reg=True):   
        """ Node convolution layer
            x:       input FC features, N x n x 1 x Cin
            Cout:    number of filters
            reg:     regularization rate
            is_reg:  whether uses regularization
            is_relu: whether uses leaky ReLU
            return:  output FC features, N x 1 x 1 x Cout
        """         
        n= int(x.get_shape()[1])
        if is_reg==True:         
            x = tf.layers.conv2d(inputs=x, filters=Cout, kernel_size=[n,1], 
                                 kernel_regularizer= tf.contrib.layers.l2_regularizer(scale=reg))
        else:
            x = tf.layers.conv2d(inputs=x, filters=Cout, kernel_size=[n,1])                
        return tf.nn.leaky_relu(x, alpha=0.33) if is_relu else x        

    

    def MLP(self, x, r, reg, is_reg=True):
        """ 2-layer bottleneck MLP 
            x:       input features, N x Cin
            r:       bottleneck ratio           
            reg:     regularization rate
            is_reg:  whether uses regularization
            return:  output features, N x Cout(=Cin)      
        """        
        Cin= int(x.get_shape()[1])
        with tf.variable_scope('fc1'):            
            x = self.fc(x, int(Cin/r), reg, is_relu=False, is_reg=is_reg)   
            x = tf.nn.relu(x)
        with tf.variable_scope('fc2'):            
            x = self.fc(x, Cin, reg, is_relu=False, is_reg=is_reg)     
        return x        
          
    
    
    def fc(self, x, Cout, reg, is_relu=True, is_reg=True):
        """ Fully connected layer
            x:       input features, N x Cin
            Cout:    number of hidden nodes
            reg:     regularization rate
            is_reg:  whether uses regularization
            is_relu: whether uses leaky ReLU
            return:  output features, N x Cout
        """
        if is_reg==True: 
            x = tf.layers.dense(x, units=Cout, 
                                kernel_regularizer= tf.contrib.layers.l2_regularizer(scale=reg))
        else:
            x = tf.layers.dense(x, units=Cout)
        return tf.nn.leaky_relu(x, alpha=0.33) if is_relu else x
   

    def FCconv(self, x, Cout, r, reg, is_relu=True, is_reg=True):
        """ Functional connectivity convolutional (FC-conv) network
            x:       input ST features, N x T x n x Cin
            Cout:    number of filters in EdgeConv and NodeConv
            r:       bottleneck ratio in MLP in FCSAtt
            reg:     regularization rate
            is_reg:  whether EdgeConv, NodeConv and FCSAtt use regularization
            is_relu: whether EdgeConv and NodeConv use leaky ReLU
            Att:     Attention map, N x n
            y:       outout FC features, N x Cout[1]
        """            
        N, T, n, Cin = x.get_shape()   
        N, T, n, Cin = int(N), int(T), int(n), int(Cin)
        
        # pearson's correlation        
        y = self.pearson(x)
        y = tf.reshape(y, [N, Cin, n, n])       
        y = tf.transpose(y, perm=[0, 2, 3, 1])             
        
        # edge convolution
        y = self.EdgeConv(y, Cout[0], reg, is_relu, is_reg)          
        
        # Spatial attention map
        Att = self.FCSAtt(y, r, reg, is_reg)                    
        y = tf.multiply(y, tf.expand_dims(tf.expand_dims(Att, 2),3))    
        
        # node convolution
        y = self.NodeConv(y, Cout[1], reg, is_relu, is_reg)
        y = tf.squeeze(y,[1,2])
       # y = tf.reshape(y, [N, n*n*Cin])            
        return Att , y                


    def FCSAtt(self, x, r, reg, is_reg=True):
        """ Functional connectivity based spatial attention(FC-SAtt)
            x:       input FC features, N x 1 x n x Cin
            r:       bottleneck ratio in MLP
            reg:     regularization rate in MLP
            is_reg:  whether MLP uses regularization
            Att:     Attention map, N x n
        """             
        #channel average pooling
        Att = tf.reduce_mean(x,axis=3)  
        Att = tf.squeeze(Att,[2])
       
        # bottleneck MLP
        with tf.variable_scope('MLP'):
            Att = self.MLP(Att , r, reg, is_reg)    
            
        # sigmoid  
        Att = tf.nn.sigmoid(Att)    
        return Att   
    
    

    def _inference(self, y, dropout, is_training):    
        
        N, T = y.get_shape()
        N, T = int(N), int(T) 
        y = tf.where(tf.is_nan(y), tf.zeros_like(y), y)     # avoid nan
        y = tf.where(tf.is_inf(y), tf.zeros_like(y), y)     # avoid inf 
        # FC-conv + FC-SAtt 
          
        # Output layer                         
        for i,M in enumerate(self.M[:-1]):
            with tf.variable_scope('output_fc{}'.format(i+1)):
                y = self.fc(y, M, self.regularization, is_relu=True, is_reg=True)
#                y = tf.layers.batch_normalization(y, training=is_training)
                #y = tf.nn.dropout(y, keep_prob=dropout)                            
        with tf.variable_scope('output_fc{}'.format(len(self.M))):
            y = self.fc(y, self.M[-1], self.regularization, is_relu=False, is_reg=True)       
                 
        return y


