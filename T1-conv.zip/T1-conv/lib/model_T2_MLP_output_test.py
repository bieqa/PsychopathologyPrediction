"""
This code implements the "Functional connectivity convolutional (FC-conv) network", 
which is a major network of the "Spatio-Temporal Directed Acyclic Graph Learning 
with Attention Mechanisms (ST-DAG-Att)" framework

The FC-conv network includes
 - FC-conv:         Functional connectivity convolution
 - FC-SAtt:         Functional connectivity based spatial attention
 - Output layer:    multi-layer MLP

May. 27, 2021  Created by Shih-Gu Huang

Copyright (C) 2021,





All rights reserved.
"""

import tensorflow as tf
import pandas as pd
from datetime import datetime


import numpy as np
import os, time, collections, shutil


from scipy import stats
from sklearn import metrics



class base_model(object):
    
    def __init__(self):
        self.regularizers = []
    
    # High-level interface which runs the constructed computational graph.
    def AttExhibit(self, data, labels=None, sess=None):
       
        
        N = data.shape[0]
        n = data.shape[1]
        
        # Count number of nodes after spatial pooling, n0 + n1 + ...
        nall = n

        # Read all individual masks in training 
        Att = np.empty([N , nall])
      #  variable_list = []

        sess = self._get_session(sess)
        for begin in range(0, N, self.batch_size):
            end = begin + self.batch_size
            end = min([end, N])
            
            batch_data = np.zeros((self.batch_size, data.shape[1]))    
            tmp_data = data[begin:end,:]                                            
            if type(tmp_data) is not np.ndarray:
                tmp_data = tmp_data.toarray()  # convert sparse matrices
            batch_data[:end-begin] = tmp_data
            feed_dict = {self.ph_data: batch_data, self.ph_dropout: 1.0 , self.ph_is_training: False}  
            batch_Att = sess.run([self.op_Att], feed_dict) 
            
            if type(batch_Att) is not np.ndarray:
                batch_Att = np.array(batch_Att)
            if (end-begin==32):
                Att[begin:end,:] = batch_Att[0:end-begin,:]   
        np.set_printoptions(precision=4,suppress=True)
        #  Update the summation of binary masks
        
        # save the summation of binary masks of each epoch into file
        f=open(self._get_path('') +  'att1.txt','a')
        for sub in range(0, N-1):
            np.savetxt(f, Att[sub, :] , fmt='%1.7f', delimiter=",", newline="; ")
            f.write("\n")
        f.close()
        
        return Att 
    
    def predict(self, data, labels=None, sess=None):
        """
        Run one prediction against the full epoch of data.
        sess: the session in which the model has been trained.
        data:        ST data,  N x T x n (number of samples x number of time points x number of nodes)
        labels:      real measures, N
        predictions: predicted measures, N
        """                    
        loss = 0
        N = data.shape[0]
        nall = data.shape[1]

        # Read all individual masks in training 
        Att = np.empty([N , nall])
        predictions = np.empty(N)
        feature = np.empty([N, self.M[-2]])
        
        sess = self._get_session(sess)
        for begin in range(0, N, self.batch_size):
            end = begin + self.batch_size
            end = min([end, N])
            
            batch_data = np.zeros((self.batch_size, data.shape[1])) 
            tmp_data = data[begin:end,:] 
            if type(tmp_data) is not np.ndarray:
                tmp_data = tmp_data.toarray()  # convert sparse matrices
            batch_data[:end-begin] = tmp_data 
            feed_dict = {self.ph_data: batch_data, self.ph_dropout: 1.0 , self.ph_is_training: False}     
            
            # Compute loss if labels are given.
            if labels is not None:
                if labels.ndim == 1:
                    batch_labels = np.zeros(self.batch_size)
                    batch_labels[:end-begin] = labels[begin:end]
                    feed_dict[self.ph_labels] = batch_labels
                    batch_pred, batch_loss, batch_feature, batch_Att = sess.run([self.op_prediction, self.op_loss, self.op_feature, self.op_Att], feed_dict)
                else:
                    batch_labels = np.zeros((self.batch_size, labels.shape[1]))
                    batch_labels[:end-begin,:] = labels[begin:end,:]
                    feed_dict[self.ph_labels] = batch_labels
                    batch_pred, batch_loss, batch_feature, batch_Att = sess.run([self.op_prediction, self.op_loss, self.op_feature, self.op_Att], feed_dict)
                    
                loss += batch_loss
            else:
                batch_pred, batch_feature = sess.run([self.op_prediction, self.op_feature], feed_dict)
                
            predictions[begin:end] = batch_pred[:end-begin]
            feature[begin:end,:] = batch_feature[:end-begin,:]
            Att[begin:end,:] = batch_Att[0:end-begin,:]  
        if labels is not None:
            return predictions, loss * self.batch_size / N, feature, Att       
        else:
            return predictions,feature, Att            
        
     
        
    def evaluate(self, data, labels, sess=None):
        """
        Run one evaluation against the full epoch of data.
        Return the precision and the number of correct predictions.
        Batch evaluation saves memory and enables this to run on smaller GPUs.
        sess: the session in which the model has been trained.
        data:        ST data,  N x T x n (number of samples x number of time points x number of nodes)
        labels:      real measures, N
        predictions: predicted measures, N
        loss:        MSE + regularization
        mse, mae, corr, pval:  evaluation metrices
        """
        t_process, t_wall = time.process_time(), time.time() # version Python 3
#        t_process, t_wall = time.clock(), time.time() # version Python 2
        predictions, loss, feature, att = self.predict(data, labels, sess)             

        mse = metrics.mean_squared_error(labels, predictions)    
        mae = metrics.mean_absolute_error(labels, predictions)
        corr, pval = stats.pearsonr(labels, predictions)

        string = 'loss: {:.2f} '.format(loss)
        if sess is None:
            string += '\ntime: {:.0f}s (wall {:.0f}s)'.format(time.process_time()-t_process, time.time()-t_wall)    
        return string, loss, predictions, mse, mae, corr, pval, feature, att



    def fit(self, learning_rate, num_epochs, decay_steps, finetune=True, finetune_fc=False):
        """
        fit the model using training and validation sets
        train_data: training ST data,  N1 x T x n (number of training samples x number of time points x number of nodes)
        train_labels: training labels, N1
        val_data: validation ST data,  N2 x T x n (number of validation samples x number of time points x number of nodes)
        val_labels: validation labels, N2     
        val_loss_list, val_mse_list,  val_mae_list,  val_corr_list, val_pval_list: list of validation loss and metrices
        """              
        config=tf.ConfigProto(allow_soft_placement=True, log_device_placement=True)  
        config.gpu_options.per_process_gpu_memory_fraction=0.9 # set the portion of memory used
        sess = tf.Session(graph=self.graph, config=config)        
        sess.run(self.op_init)
        
        ckpt = tf.train.get_checkpoint_state(self._get_path('checkpoints'))
       
        # Load the latest model
        if finetune:
            # Restore from check point
            shutil.copytree(self._get_path('checkpoints'), self._get_path('checkpoints_orig')) # keep a copy of the pretrained model
            path = os.path.join(self._get_path('checkpoints'), 'model')
            self.op_saver.restore(sess, ckpt.model_checkpoint_path)
            self.learning_rate = learning_rate
            self.num_epochs = num_epochs
            self.decay_steps = decay_steps
            self.finetune_fc = finetune_fc
        else:
            shutil.rmtree(self._get_path('summaries'), ignore_errors=True)
            shutil.rmtree(self._get_path('checkpoints'), ignore_errors=True)
            os.makedirs(self._get_path('checkpoints'))
            path = os.path.join(self._get_path('checkpoints'), 'model')
            self.finetune_fc = finetune_fc
       
        # Start the queue runners
        tf.train.start_queue_runners(sess = sess)
        
        sess.close()       



    def get_var(self, name):
        """ read variable value"""
        sess = self._get_session()
        var = self.graph.get_tensor_by_name(name + ':0')
        val = sess.run(var)
        sess.close()
        return val


    def build_graph(self, T0,  C):
        """
        Build the computational graph of the network model.
        T0: number of time points of input data
        n0: number of nodes of input data
        C: number of prediction measures
        """
        self.graph = tf.Graph()
        with self.graph.as_default():

            # Inputs.
            with tf.name_scope('inputs'):
                self.ph_data = tf.placeholder(tf.float32, (self.batch_size, T0), 'data') 
                if C == 1:
                    self.ph_labels = tf.placeholder(tf.float32, (self.batch_size), 'labels')
                    self.ph_labels2 = tf.placeholder(tf.float32, (self.batch_size), 'labels1')
                else:    
                    self.ph_labels = tf.placeholder(tf.float32, (self.batch_size, C), 'labels')
                    self.ph_labels2 = tf.placeholder(tf.float32, (self.batch_size, C), 'labels2')
                self.ph_dropout = tf.placeholder(tf.float32, (), 'dropout')
                self.ph_is_training = tf.placeholder(tf.bool, (), 'is_training')                          
                self.ph_lr = tf.placeholder(tf.float32, (), 'learning_rate')

            # Model.
            op_logits, op_Att, op_feature = self.inference(self.ph_data, self.ph_dropout, self.ph_is_training)
            self.op_loss, self.op_loss_average = self.loss_rmse(op_logits, self.ph_labels, self.regularization)
            self.op_train = self.training(self.op_loss, self.ph_lr,
                    self.decay_steps, self.decay_rate, self.momentum, self.finetune_fc) # changed for finetuning with different learning rate
            self.op_prediction = self.prediction(op_logits)

            # Initialize variables, i.e. weights and biases.
            self.op_init = tf.global_variables_initializer()
            self.op_Att = op_Att
            self.op_feature = op_feature
            
            # Summaries for TensorBoard and Save for model parameters.
            self.op_summary = tf.summary.merge_all()
            self.op_saver = tf.train.Saver(max_to_keep=5)
        
        self.graph.finalize()
    
    
    
    def inference(self, data, dropout, is_training):             
        """
        It builds the model, i.e. the computational graph, as far as
        is required for running the network forward to make predictions
        data:        ST data, N x T x n (number of samples x number of time points x number of nodes)
        dropout:     dropout rate
        is_training: model training mode
        """
        logits, Att, feature = self._inference(data, dropout, is_training)                     
        return logits, Att, feature
    
    

    def prediction(self, logits):
        """Return the predictions."""
        with tf.name_scope('prediction'):
            prediction = logits[:,0]                                                                                  
            return prediction



    def loss_rmse(self, y_pred, y, regularization):                           
        """Adds to the inference model the layers required to generate loss (RMSE)."""
        with tf.name_scope('loss_rmse'):
            with tf.name_scope('root_mean_squared_error'):
                y = tf.to_float(y)
                rmse = tf.sqrt(tf.reduce_mean(tf.square((y - y_pred[:,0]))))
                rmse = tf.Print(rmse, [rmse], message="Root mean squared error: ")
            with tf.name_scope('regularization'):
                l2_loss = tf.losses.get_regularization_loss()                
#                regularization *= tf.add_n(self.regularizers)       # if _weight_variable() or _bias_variable() is used
#                regularization += l2_loss
                regularization = l2_loss
                regularization = tf.Print(regularization, [regularization], message="regularization: ")
                
            loss = rmse + regularization                                     
            
            # Summaries for TensorBoard.
            tf.summary.scalar('loss/root_mean_squared_error', rmse)
            tf.summary.scalar('loss/regularization', regularization)
            tf.summary.scalar('loss/total', loss)
            with tf.name_scope('averages'):
                averages = tf.train.ExponentialMovingAverage(0.9)
                op_averages = averages.apply([rmse, regularization, loss])
                tf.summary.scalar('loss/avg/root_mean_squared_error', averages.average(rmse))
                tf.summary.scalar('loss/avg/regularization', averages.average(regularization))
                tf.summary.scalar('loss/avg/total', averages.average(loss))
                with tf.control_dependencies([op_averages]):
                    loss_average = tf.identity(averages.average(loss), name='control')
            return loss, loss_average


        
        
    def training(self, loss, learning_rate, decay_steps, decay_rate=0.95, momentum=0.9, finetune_fc=False):
        """Adds to the loss model the Ops required to generate and apply gradients."""
        with tf.name_scope('training'):
            # Learning rate.
            global_step = tf.Variable(0, name='global_step', trainable=False)
            print('Global step: ', tf.cast(global_step, np.int32))            
            print('Learning rate before decay: ', learning_rate)                    
            if decay_rate != 1:
                learning_rate = tf.train.exponential_decay(
                        learning_rate, global_step, decay_steps, decay_rate, staircase=True)
                              
            tf.summary.scalar('learning_rate', learning_rate)
            
            update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)  # for batch normalization
            with tf.control_dependencies(update_ops):
            # Optimizer.
                if momentum == 0:
                    optimizer = tf.train.GradientDescentOptimizer(learning_rate)
                else:
                    optimizer = tf.train.AdamOptimizer(learning_rate)
                
                if finetune_fc == True:                                                           
                    fc_vars = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, 'fc')
                    logits_vars = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, 'logits')
                    train_vars = []
                    train_vars.append(fc_vars)
                    train_vars.append(logits_vars)
                    print(train_vars)
                else:
                    train_vars = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES)
                    print(train_vars)

            with tf.control_dependencies(update_ops):
                grads = optimizer.compute_gradients(loss, var_list=train_vars)       

            with tf.control_dependencies(update_ops):                
                op_gradients = optimizer.apply_gradients(grads, global_step=global_step)

            # Histograms.
            for grad, var in grads:
                if grad is None:
                    print('warning: {} has no gradient'.format(var.op.name))
                else:
                    tf.summary.histogram(var.op.name + '/gradients', grad)
                                                   
            with tf.control_dependencies([op_gradients] + update_ops):
                op_train = tf.identity(learning_rate, name='control')

            return op_train



    def _get_path(self, folder):
        return os.path.join(self.dir_name, folder)

    
    
    def _get_session(self, sess=None):
        """Restore parameters if no session given."""
        if sess is None:
            sess = tf.Session(graph=self.graph)
            filename = tf.train.latest_checkpoint(self._get_path('checkpoints'))
            print('Checkpoint filename: ', filename)
            self.op_saver.restore(sess, filename)
        return sess



    def _weight_variable(self, shape, is_reg=True):
        """User-defined weight variables"""        
        initial = tf.truncated_normal_initializer(0, 0.1)
        var = tf.get_variable('weights', shape, tf.float32, initializer=initial)
        if is_reg:
            self.regularizers.append(tf.nn.l2_loss(var))
        tf.summary.histogram(var.op.name, var)
        return var



    def _bias_variable(self, shape, is_reg=True):
        """User-defined bias variables"""            
        initial = tf.constant_initializer(0.1)
        var = tf.get_variable('bias', shape, tf.float32, initializer=initial)
        if is_reg:
            self.regularizers.append(tf.nn.l2_loss(var))
        tf.summary.histogram(var.op.name, var)
        return var



class FCCNN(base_model):
    """
    Functional connectivity convolutional (FC-conv) network
    T0:   number of time points of input data
    n0:   number of nodes of input data    
    C:    number of prediction measures
        
    The following are hyper-parameters    
        CeCn:number of filters of EdgeConv and NodeConv in FC-conv
        r:   bottleneck ratio of MLP in FC-SAtt 
        M:   number of hidden neurons of fully connected layers in output prediction layer

    Training parameters:
        num_epochs:    Number of training epochs.
        learning_rate: Initial learning rate.
        decay_rate:    Base of exponential decay. No decay with 1.
        decay_steps:   Number of steps after which the learning rate decays.
        momentum:      Momentum. 0 indicates no momentum.
        is_training:   model training mode

    Regularization parameters:
        regularization: L2 regularizations of weights and biases.
        dropout:        Dropout in FC layers: probability to keep hidden neurons. No dropout with 1.
        batch_size:     Batch size. Must divide evenly into the dataset sizes.
        eval_frequency: Number of steps between evaluations.

    Directories:
        dir_name: Name for save directory (including summaries and model parameters).
    """


    def __init__(self, T0, C, r, M,
                finetune=True, finetune_fc=False,
                num_epochs=10, learning_rate=0.001, decay_rate=0.95, decay_steps=20, momentum=0.9,
                regularization=0.001, dropout=0, batch_size=32, eval_frequency=20,
                dir_name='', decay_factor=0.1 , is_training='True'):   
        super().__init__() # version Python 3
#        super(stgcnn, self).__init__() # version Python 2
                      
        # Store attributes and bind operations.
        self.r, self.M = r, M       
        self.finetune = finetune
        self.finetune_fc = finetune_fc
        self.num_epochs, self.learning_rate = num_epochs, learning_rate
        self.regularization, self.dropout = regularization, dropout
        self.batch_size, self.eval_frequency = batch_size, eval_frequency
        self.dir_name = dir_name      

        self.decay_rate, self.momentum = decay_rate, momentum
        self.decay_factor = decay_factor
        
        if type(decay_steps) is list == True:
            self.decay_steps = decay_steps
        else:
            self.decay_steps = decay_steps
        
        print ('decay_steps = ', self.decay_steps)
        print ('dir_name = ', self.dir_name)
        
        # Build the computational graph.
        self.build_graph(T0, C)                                        
        

    def MLP(self, x, r, reg, is_reg=True):
        """ 2-layer bottleneck MLP 
            x:       input features, N x Cin
            r:       bottleneck ratio           
            reg:     regularization rate
            is_reg:  whether uses regularization
            return:  output features, N x Cout(=Cin)      
        """        
        Cin= int(x.get_shape()[1])
        with tf.variable_scope('fc1'):            
            x = self.fc(x, int(Cin/r), reg, is_relu=False, is_reg=is_reg)   
            x = tf.nn.relu(x)
        with tf.variable_scope('fc2'):            
            x = self.fc(x, Cin, reg, is_relu=False, is_reg=is_reg)     
        return x        
          
    
    
    def fc(self, x, Cout, reg, is_relu=True, is_reg=True):
        """ Fully connected layer
            x:       input features, N x Cin
            Cout:    number of hidden nodes
            reg:     regularization rate
            is_reg:  whether uses regularization
            is_relu: whether uses leaky ReLU
            return:  output features, N x Cout
        """
        if is_reg==True: 
            x = tf.layers.dense(x, units=Cout, 
                                kernel_regularizer= tf.contrib.layers.l2_regularizer(scale=reg))
        else:
            x = tf.layers.dense(x, units=Cout)
        return tf.nn.leaky_relu(x, alpha=0.33) if is_relu else x 
   
    

    def _inference(self, y, dropout, is_training):    
        
               # Size of input data
        with tf.variable_scope('MLP'):
            Att = self.MLP(y , self.r, self.regularization, is_reg=True)               
        Att = tf.nn.sigmoid(Att)        
        y2 = tf.multiply(y, Att)  
        
        with tf.variable_scope('output_fc{}'.format(0)):
            y2 = self.fc(y2, self.M[-3], self.regularization, is_relu=True, is_reg=True)
#                y = tf.layers.batch_normalization(y, training=is_training)
            #y2 = tf.nn.dropout(y2, keep_prob=dropout)  
        with tf.variable_scope('output_fc{}'.format(1)):
            y2 = self.fc(y2, self.M[-2], self.regularization, is_relu=True, is_reg=True)
            feature = y2

        with tf.variable_scope('output_fc{}'.format(len(self.M))):
            y2 = self.fc(y2, self.M[-1], self.regularization, is_relu=False, is_reg=True) 
       
                 
        return y2, Att, feature


