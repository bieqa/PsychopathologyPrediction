"""
Prediction of fluid intelligence (gF) via 5-fold (K=5) cross-validation on ABCD dataset 
using the "Functional connectivity convolutional (FC-conv) network", 
which is a major network of the "Spatio-Temporal Directed Acyclic Graph Learning 
with Attention Mechanisms (ST-DAG-Att)" framework

The FC-conv network includes
 - FC-conv:         Functional connectivity convolution
 - FC-SAtt:         Functional connectivity based spatial attention
 - Output layer:    multi-layer MLP

----------------------------------------------------------------
Input data:
./data/ABCD7693.mat: 
        'fMRI'      fMRI, number of all samples x number of time points x number of nodes
        'List'      List Sorting Working Memory,            number of all samples x 1
        'Pattern'   Pattern Comparison Processing Speed,    number of all samples x 1
        'Picture'   Picture SequenceMemory,                 number of all samples x 1
        'Flanker'   Flanker,                                number of all samples x 1
        'CardSort'  Dimensional Change Card Sort,           number of all samples x 1
         
./data/TrainValidTest_Idx_r?.mat: 
        'TrainSet'   K x 1 cell (consists of K arrays), training sample indices for K folds 
        'ValidSet'   K x 1 cell (consists of K arrays), validation sample indices for K folds
        'TestSet'    K x 1 cell (consists of K arrays), testing sample indices for K folds         
                            

----------------------------------------------------------------
Output results: 
./result/?/performance_Kfold.csv
        overall K-fold performance (correlation, MAE, RMSE, ... between real and predicted measures) 
  
./result/?/performance_test.csv: 
        K performances of K folds (correlation, MAE, RMSE, ... between real and predicted measures) 

./result/?/performance_test_z.csv: 
        K performances of K folds (correlation, MAE, RMSE, ... between Z-scores of real and predicted measures) 

./result/?/predict_test.csv: 
        real and predicted measures of all K folds
        
./result/?/predict_test_z.csv: 
        Z-scores of real and predicted measures of all K folds
        
./result/?/0 ~ K-1/:   Results of each fold, including
    performance_trainvalid.csv: training and validation performance 
    performance_test.csv:       testing performance
    performance_test_z.csv:     testing performance (Z-scores)    
    predict_test.csv:           real and predicted measures in testing set
    predict_test_z.csv:         real and predicted measures (Z-scores) in testing set
    other files:                saved models for future use (eg. transfer learning) 
----------------------------------------------------------------


May. 27, 2021  Created by Shih-Gu Huang

"""

from lib import model_T4_multiimage_phen as models
import numpy as np
from scipy import sparse, stats
from sklearn import preprocessing, metrics
import pandas as pd
import h5py
import math
import os
import time
import datetime


os.environ["CUDA_VISIBLE_DEVICES"]="0" 

run=1   # -th experiment
foldIDS=5   # number of folds


params = dict()
# ----- Architecture setting ----------------------------------------------------------
params['CeCn'] = [128, 256]     # number of filters of EdgeConv and NodeConv in FC-conv
params['r']    = 4              # bottleneck ratio in MLP in FC-SAtt 
#params['M']    = [128,32, 34,42,34,32,1,6,1] 
params['M']    = [128,64, 34,42,34,238,1,6,1] 
# ----- Hyper-parameters ------------------------------------------------------
params['num_epochs']     = 50      # number of epochs
params['batch_size']     = 32       # batch size
params['learning_rate']  = 0.01    # initial learning rate
params['decay_rate']     = 1-0.05   # decay of learning rate
decay_steps   = 10                 # decay steps
params['momentum']       = 0.9      # momentum
params['dropout']        = 1.0-0.4  # keep_prob rate in dropout
params['regularization'] = 0.001    # regularization 
params['eval_frequency'] = 50       # number of iterations to display results on workspace 


# ----- data file names -------------------------------------------------------
DATADIR = '../data'                                 # data folder
Datafile='example_selected_feature.mat'                             # fMRI data
Setfile='TrainValidTest_demo_Idx_r'+str(run)+'.mat'       # indices of training, validation, testing sets
SAVEDIR = 'result'                                  # result folder

# path of files 
path = os.path.dirname(os.path.realpath(__file__))
Datafile=os.path.join(path, DATADIR, Datafile)                
Setfile=os.path.join(path, DATADIR, Setfile)                


# ----- result folder and file names -----------------------------------------------------
szDatetime = datetime.datetime.now().strftime('%s')
szDatetime0 = szDatetime

szDatetime = 'PNC_gF_'+str(foldIDS)+'fold_un_multiimage_r' + str(run)+'_'+ szDatetime

save_dir_group = os.path.join(path, SAVEDIR, szDatetime)               
Labelfile   = os.path.join(save_dir_group , 'predict_test.csv')          
Accfile = os.path.join(save_dir_group, 'performance_test.csv')        
Resultfile  = os.path.join(save_dir_group, 'performance_Kfold.csv')  


# ----- Load data and real measures --------------------------------------------------
print('Loading data ...')
f = h5py.File(Datafile, 'r')
print(list(f.keys()),'\n')

#data = np.array(f.get('FC_selection')).astype(float) 
#data2 =np.array(f.get('SC_selection')).astype(float)
#data2 = np.array(f.get('PNC_t1_subb')).astype(float)  
#data = np.concatenate((data, data2), axis=1)      
Fear = np.array(f.get('Overall')).astype(float)[0]
  # Fluid IQ
target = Fear
#data=np.abs(data)
f.close()

target = np.round(target, 1)
# ----- Load indices of training, validation, testing sets --------------------
fset = h5py.File(Setfile, 'r')
TrainSet_Kfold = fset.get('TrainSet')
TestSet_Kfold = fset.get('TestSet')
ValidSet_Kfold = fset.get('ValidSet')



Kfold_time = 0.0 # whole training time
# ----- K-fold cross-validation -----------------------------------------------  
for foldID in range(foldIDS): 
    start_time = time.time()   # count training time of each fold    
    f = h5py.File(Datafile, 'r')

    data_name = 'FC_selection' + str(foldID+1)
    data_name2 = 'SC_selection' + str(foldID+1)
    data_name3 = 'thick_selection' + str(foldID+1)
    data_name4 = 'volume_selection' + str(foldID+1)
    data_name5 = 'area_selection' + str(foldID+1)
    data_name6 = 'Phen_noglo'


    data = np.array(f.get(data_name)).astype(float)  
    data2 = np.array(f.get(data_name2)).astype(float) 
    data3 = np.array(f.get(data_name3)).astype(float)  
    data4 = np.array(f.get(data_name4)).astype(float)  
    data5 = np.array(f.get(data_name5)).astype(float)  
    data6 = np.array(f.get(data_name6)).astype(float)  
    
    f.close()
    print('Start fold ID:', foldID)
    
    # ----- path of result files of k-th fold ---------------------------------      
    save_dir = os.path.join(save_dir_group, str(foldID))  
    params['dir_name']       = save_dir
    
    Labelfile_fold   = os.path.join(save_dir , 'predict_test.csv')       
    Accfile_fold = os.path.join(save_dir, 'performance_test.csv')  
    
    
    # ----- k-th fold training/validation/testing data and target real measures -------------
    print('Data splitting...')   
    TrainSet = fset[TrainSet_Kfold[0,foldID]][()].astype(int)[0] -1
    ValidSet = fset[ValidSet_Kfold[0,foldID]][()].astype(int)[0] -1  
    TestSet = fset[TestSet_Kfold[0,foldID]][()].astype(int)[0] -1
    

    data_train = data[TrainSet,:]
    data_valid = data[ValidSet,:]    
    data_test = data[TestSet,:]
    
    
    data2_train = data2[TrainSet,:]
    data2_valid = data2[ValidSet,:]    
    data2_test = data2[TestSet,:]

    data3_train = data3[TrainSet,:]
    data3_valid = data3[ValidSet,:]    
    data3_test = data3[TestSet,:]

    data4_train = data4[TrainSet,:]
    data4_valid = data4[ValidSet,:]    
    data4_test = data4[TestSet,:]
    
    
    data5_train = data5[TrainSet,:]
    data5_valid = data5[ValidSet,:]    
    data5_test = data5[TestSet,:]

    data6_train = data6[TrainSet,:]
    data6_valid = data6[ValidSet,:]    
    data6_test = data6[TestSet,:] 
    
    target_train = target[TrainSet]
    target_valid = target[ValidSet]    
    target_test =  target[TestSet]
    target_test0 = np.copy(target_test)

    ## ----- Z-score of real measures   --------------------------------------
    T_train = np.copy(target_train)
    T_valid = np.copy(target_valid)    
    T_test = np.copy(target_test)
    target_scaler = preprocessing.StandardScaler().fit(T_train.reshape(-1,1))
    target_train = target_scaler.transform(T_train.reshape(-1,1))[:,0]    
    target_valid = target_scaler.transform(T_valid.reshape(-1,1))[:,0]        
    target_test = target_scaler.transform(T_test.reshape(-1,1))[:,0]
    

    ## ----- remove mean and scale to unit variance at each node --------------
    # For each node, the mean and SD of fMRI across time and sujbects = 0 , 1
    n_train, T0= data_train.shape  #  (number of samples x number of time points x number of nodes)
    n_valid = data_valid.shape[0]    
    n_test = data_test.shape[0]    
#          
    n_train, T1= data3_train.shape
    n_train, T2= data4_train.shape
    n_train, T3= data5_train.shape
    n_train, T4= data6_train.shape
   
#    X_train = np.reshape(np.copy(data_train),[n_train*T0, 1])   
#    X_valid = np.reshape(np.copy(data_valid),[n_valid*T0, 1])             
#    X_test = np.reshape(np.copy(data_test),[n_test*T0, 1])       
#    scaler = preprocessing.MinMaxScaler().fit(X_train)     
#    data_train = np.reshape(scaler.transform(X_train),[n_train, T0])  
#    data_valid = np.reshape(scaler.transform(X_valid),[n_valid, T0])      
#    data_test = np.reshape(scaler.transform(X_test),[n_test, T0]) 
    
#    X_train2 = np.reshape(np.copy(data2_train),[n_train*T0, 1])   
#    X_valid2 = np.reshape(np.copy(data2_valid),[n_valid*T0, 1])             
#    X_test2 = np.reshape(np.copy(data2_test),[n_test*T0, 1])       
#    scaler2 = preprocessing.MinMaxScaler().fit(X_train2)     
#    data2_train = np.reshape(scaler2.transform(X_train2),[n_train, T0])  
#    data2_valid = np.reshape(scaler2.transform(X_valid2),[n_valid, T0])      
#    data2_test = np.reshape(scaler2.transform(X_test2),[n_test, T0])
#    
#    X_train3 = np.reshape(np.copy(data3_train),[n_train*T1, 1])   
#    X_valid3 = np.reshape(np.copy(data3_valid),[n_valid*T1, 1])             
#    X_test3 = np.reshape(np.copy(data3_test),[n_test*T1, 1])       
#    scaler3 = preprocessing.MinMaxScaler().fit(X_train3)     
#    data3_train = np.reshape(scaler3.transform(X_train3),[n_train, T1])  
#    data3_valid = np.reshape(scaler3.transform(X_valid3),[n_valid, T1])      
#    data3_test = np.reshape(scaler3.transform(X_test3),[n_test, T1])
#    
#    X_train4 = np.reshape(np.copy(data4_train),[n_train*T2, 1])   
#    X_valid4 = np.reshape(np.copy(data4_valid),[n_valid*T2, 1])             
#    X_test4 = np.reshape(np.copy(data4_test),[n_test*T2, 1])       
#    scaler4 = preprocessing.MinMaxScaler().fit(X_train4)     
#    data4_train = np.reshape(scaler4.transform(X_train4),[n_train, T2])  
#    data4_valid = np.reshape(scaler4.transform(X_valid4),[n_valid, T2])      
#    data4_test = np.reshape(scaler4.transform(X_test4),[n_test, T2])
#    
#    X_train5 = np.reshape(np.copy(data5_train),[n_train*T3, 1])   
#    X_valid5 = np.reshape(np.copy(data5_valid),[n_valid*T3, 1])             
#    X_test5 = np.reshape(np.copy(data5_test),[n_test*T3, 1])       
#    scaler5 = preprocessing.MinMaxScaler().fit(X_train5)     
#    data5_train = np.reshape(scaler5.transform(X_train5),[n_train, T3])  
#    data5_valid = np.reshape(scaler5.transform(X_valid5),[n_valid, T3])      
#    data5_test = np.reshape(scaler5.transform(X_test5),[n_test, T3])
    
    #data_train=np.concatenate((data_train,data2_train, data3_train, data4_train,data5_train),axis=1)#, , data6_train
    #data_valid=np.concatenate((data_valid,data2_valid, data3_valid, data4_valid,data5_valid),axis=1)# , data6_valid
    #data_test=np.concatenate((data_test, data2_test, data3_test, data4_test, data5_test),axis=1)#, data6_test
    
    
    # ------- format data and target measures to float32 -------------------------------
    data_train = data_train.astype(np.float32)
    data_valid = data_valid.astype(np.float32)
    data_test = data_test.astype(np.float32)
    
    data2_train = data2_train.astype(np.float32)
    data2_valid = data2_valid.astype(np.float32)
    data2_test = data2_test.astype(np.float32)
    
    data3_train = data3_train.astype(np.float32)
    data3_valid = data3_valid.astype(np.float32)
    data3_test = data3_test.astype(np.float32)
    
    data4_train = data4_train.astype(np.float32)
    data4_valid = data4_valid.astype(np.float32)
    data4_test = data4_test.astype(np.float32)
    
    data5_train = data5_train.astype(np.float32)
    data5_valid = data5_valid.astype(np.float32)
    data5_test = data5_test.astype(np.float32)
    
    data6_train = data6_train.astype(np.float32)
    data6_valid = data6_valid.astype(np.float32)
    data6_test = data6_test.astype(np.float32)
    
    n_train, T0= data_train.shape  #  (number of samples x number of time points x number of nodes)
    
#    data2_train = data2_train.astype(np.float32)
#    data2_valid = data2_valid.astype(np.float32)
#    data2_test = data2_test.astype(np.float32)
    
    target_train = target_train.astype(np.float32)
    target_valid = target_valid.astype(np.float32)
    target_test  = target_test.astype(np.float32)
    
    
    print('Size of training set: ', data5_train.shape)
    print('Size of validation set: ', data5_valid.shape)
    print('Size of testing set: ', data5_test.shape,'\n')   
    
    
#    print('Size of training set: ', data2_train.shape)
#    print('Size of validation set: ', data2_valid.shape)
#    print('Size of testing set: ', data2_test.shape,'\n')   
    
          
    
    # ----- Training and validation -----------------------------------------------
    params['decay_steps']    = (np.multiply(decay_steps, n_train / params['batch_size'])).astype(int)
    model = models.FCCNN(T0, T0, T1, T2, T3, T4,  1, **params)
        
    val_loss_list, val_mse_list,  val_mae_list,  val_corr_list, val_pval_list  = \
    model.fit(data_train, data2_train,data3_train,data4_train,data5_train,data6_train,target_train, data_valid, data2_valid,data3_valid,data4_valid,data5_valid,data6_valid,target_valid, params['learning_rate'],params['num_epochs'],params['decay_steps'])
      

    #------training time---------------------------------------------
    fold_time = float(time.time() - start_time)
    Kfold_time = Kfold_time + fold_time
    format_str = 'training time of this fold: %.3f, epoch time this fold: %.3f'
    print (format_str % (fold_time, fold_time/params['num_epochs']),'\n') 
    
  
    # ----- Evaluate performance on testing set -----------------------------------
    # performace of Z-score of predicted measure
    res, test_loss, predictions, test_mse, test_mae, test_corr, test_pval = model.evaluate(data_test, data2_test,data3_test,data4_test,data5_test,data6_test,target_test)         
    test_rmse = np.sqrt(test_mse)
    test_corr2 = math.pow(test_corr, 2) 
    
    # save values and performance of Z-score of predicted measure   
    df = {'foldID':foldID,  'mse':test_mse, 'rmse':test_rmse, 'mae':test_mae, \
          'r': test_corr, 'pval':test_pval, 'r^2':test_corr2, \
          'whole time': fold_time,'epoch time': fold_time/params['num_epochs']}    
    df = pd.DataFrame(data=df, index=[0])
    df.to_csv(Accfile_fold.replace('.csv','_z.csv'), mode='a+', header=True) 
    df.to_csv(Accfile.replace('.csv','_z.csv'), mode='a+', header=(foldID==0))     
    df_predict = {'Idx':TestSet, 'Actual':target_test, 'Predicted':predictions}
    df_predict = pd.DataFrame(data=df_predict, dtype=np.float32)
    df_predict.to_csv(Labelfile_fold.replace('.csv','_z.csv'), mode='a+', header=True) 
    df_predict.to_csv(Labelfile.replace('.csv','_z.csv'), mode='a+', header=(foldID==0)) 
    
    
#      performace of predicted measure
    predictions0 = target_scaler.inverse_transform(predictions.reshape(-1,1))[:,0]
    
   # predictions0 = predictions
    test_mse = metrics.mean_squared_error(target_test0, predictions0)
    test_rmse = np.sqrt(test_mse)
    test_mae = metrics.mean_absolute_error(target_test0, predictions0)
    test_corr, test_pval = stats.pearsonr(target_test0, predictions0)
    test_corr2 = math.pow(test_corr, 2) 
    print('RMSE of test samples: ', str(test_rmse))
    print('MAE of test samples: ', str(test_mae))
    print('Pearson correlation of test samples: ', str(test_corr))
    print('P-value for Pearson correlation of test samples: ', str(test_pval))
    print('Coefficient of determination of test samples: ', str(test_corr2))
  
    # save values and performance of predicted measure
    df = {'foldID':foldID, 'mse':test_mse, 'rmse':test_rmse, 'mae':test_mae, \
          'r': test_corr, 'pval':test_pval, 'r^2':test_corr2,\
          'whole time': fold_time,'epoch time': fold_time/params['num_epochs']}   
    df = pd.DataFrame(data=df, index=[0])
    df.to_csv(Accfile_fold, mode='a+', header=True) 
    df.to_csv(Accfile, mode='a+', header=(foldID==0))         
    df_predict = {'Idx':TestSet, 'Actual':target_test0, 'Predicted':predictions0}
    df_predict = pd.DataFrame(data=df_predict, dtype=np.float32)
    df_predict.to_csv(Labelfile_fold, mode='a+', header=True) 
    df_predict.to_csv(Labelfile, mode='a+', header=(foldID==0)) 

    del model

fset.close()


# ----- Evaluate overall performance of K-fold cross-validation-----------------------------------
print('\n Overall performance:')

# read predicted values from all K folds    
V = pd.read_csv(Labelfile)
actual = np.array(V.Actual)
predictions = np.array(V.Predicted)

# evaluate overall performance
test_mse = metrics.mean_squared_error(actual, predictions)
test_rmse = np.sqrt(test_mse)
test_mae = metrics.mean_absolute_error(actual, predictions)
corr, pval = stats.pearsonr(actual, predictions)
corrsquare = math.pow(corr, 2) 
print('RMSE of test samples: ', str(test_rmse))
print('MAE of test samples: ', str(test_mae))
print('Pearson correlation of test samples: ', str(corr))
print('P-value for Pearson correlation of test samples: ', str(pval))
print('Coefficient of determination of test samples: ', str(corrsquare))

# overall training time
format_str = 'whole time: %.3f, epoch time: %.3f'
print (format_str % (Kfold_time, Kfold_time/params['num_epochs']/foldIDS))

# save the overall performance
df = {'aaidx':szDatetime0, 'mse':test_mse, 'rmse':test_rmse, 'mae':test_mae, 'r': corr, 'r^2':corrsquare, 'pval':pval,\
      'whole time': Kfold_time,'epoch time': Kfold_time/params['num_epochs']}   
df = pd.DataFrame(data=df, index=[0])
df.to_csv(Resultfile, mode='a+', header=True) 


