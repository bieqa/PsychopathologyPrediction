"""
Prediction of fluid intelligence (gF) via 5-fold (K=5) cross-validation on ABCD dataset 
using the "Functional connectivity convolutional (FC-conv) network", 
which is a major network of the "Spatio-Temporal Directed Acyclic Graph Learning 
with Attention Mechanisms (ST-DAG-Att)" framework

The FC-conv network includes
 - FC-conv:         Functional connectivity convolution
 - FC-SAtt:         Functional connectivity based spatial attention
 - Output layer:    multi-layer MLP

----------------------------------------------------------------
Input data:
./data/ABCD7693.mat: 
        'fMRI'      fMRI, number of all samples x number of time points x number of nodes
        'List'      List Sorting Working Memory,            number of all samples x 1
        'Pattern'   Pattern Comparison Processing Speed,    number of all samples x 1
        'Picture'   Picture SequenceMemory,                 number of all samples x 1
        'Flanker'   Flanker,                                number of all samples x 1
        'CardSort'  Dimensional Change Card Sort,           number of all samples x 1
         
./data/TrainValidTest_Idx_r?.mat: 
        'TrainSet'   K x 1 cell (consists of K arrays), training sample indices for K folds 
        'ValidSet'   K x 1 cell (consists of K arrays), validation sample indices for K folds
        'TestSet'    K x 1 cell (consists of K arrays), testing sample indices for K folds         
                            

----------------------------------------------------------------
Output results: 
./result/?/performance_Kfold.csv
        overall K-fold performance (correlation, MAE, RMSE, ... between real and predicted measures) 
  
./result/?/performance_test.csv: 
        K performances of K folds (correlation, MAE, RMSE, ... between real and predicted measures) 

./result/?/performance_test_z.csv: 
        K performances of K folds (correlation, MAE, RMSE, ... between Z-scores of real and predicted measures) 

./result/?/predict_test.csv: 
        real and predicted measures of all K folds
        
./result/?/predict_test_z.csv: 
        Z-scores of real and predicted measures of all K folds
        
./result/?/0 ~ K-1/:   Results of each fold, including
    performance_trainvalid.csv: training and validation performance 
    performance_test.csv:       testing performance
    performance_test_z.csv:     testing performance (Z-scores)    
    predict_test.csv:           real and predicted measures in testing set
    predict_test_z.csv:         real and predicted measures (Z-scores) in testing set
    other files:                saved models for future use (eg. transfer learning) 
----------------------------------------------------------------


May. 27, 2021  Created by Shih-Gu Huang

"""

from lib import model_FCconv_concate_2att_lr_mulscale as models

import numpy as np
from scipy import sparse, stats
from sklearn import preprocessing, metrics
import pandas as pd
import h5py
import math
import os
import time
import datetime


os.environ["CUDA_VISIBLE_DEVICES"]="0" 

run=1     # -th experiment
foldIDS=5   # number of folds


params = dict()
# ----- Architecture setting ----------------------------------------------------------
params['CeCn'] = [128, 256]     # number of filters of EdgeConv and NodeConv in FC-conv
params['r']    = 4              # bottleneck ratio in MLP in FC-SAtt 
params['M']    = [256, 128, 1]  # number of hidden nodes in fully-connected layers in output layer


# ----- Hyper-parameters ------------------------------------------------------

params['num_epochs']     = 18       # number of epochs
params['batch_size']     = 32       # batch size 
params['learning_rate']  = 1e-2    # initial learning rate
params['decay_rate']     = 1-0.05   # decay of learning rate
decay_steps   = 10                  # decay steps
params['momentum']       = 0.9      # momentum
params['dropout']        = 1.0-0.4  # keep_prob rate in dropout
params['regularization'] = 0.001    # regularization 
params['eval_frequency'] = 20       # number of iterations to display results on workspace  

# ----- data file names -------------------------------------------------------
DATADIR = '../data'                                 # data folder
Datafile='example20.mat'                             # fMRI data
Setfile='TrainValidTest_demo_Idx_r'+str(run)+'.mat'       # indices of training, validation, testing sets

#Setfile='TrainValidTest_demo_Idx_r1.mat'       # indices of training, validation, testing sets

SAVEDIR = 'result'                                  # result folder

# path of files 
path = os.path.dirname(os.path.realpath(__file__))
Datafile=os.path.join(path, DATADIR, Datafile)                
Setfile=os.path.join(path, DATADIR, Setfile)                


# ----- result folder and file names -----------------------------------------------------
szDatetime = datetime.datetime.now().strftime('%s')
szDatetime0 = szDatetime

szDatetime = 'PNC_gF_5fold_FCconv'
#szDatetime = 'PNC_gF_5fold_FCconv_net_ROI_150_0.002_20_abs_r9_1654219548'
save_dir_group = os.path.join(path, SAVEDIR, szDatetime)               
Labelfile   = os.path.join(save_dir_group , 'predict_test.csv')          
Accfile = os.path.join(save_dir_group, 'performance_test.csv')        
Resultfile  = os.path.join(save_dir_group, 'performance_Kfold.csv')  


# ----- Load data and real measures --------------------------------------------------
print('Loading data ...')
f = h5py.File(Datafile, 'r')
print(list(f.keys()),'\n')

         
data = np.array(f.get('FC_conn')).astype(float)  
Fear = np.array(f.get('Overall')).astype(float)[0]
  # Fluid IQ
target = Fear
target = np.round(target, 1)
f.close()


# ----- Load indices of training, validation, testing sets --------------------
fset = h5py.File(Setfile, 'r')
TrainSet_Kfold = fset.get('TrainSet')
TestSet_Kfold = fset.get('TestSet')
ValidSet_Kfold = fset.get('ValidSet')

#target = np.around(target, 1)

Kfold_time = 0.0 # whole training time
# ----- K-fold cross-validation -----------------------------------------------  
#for foldID in range(foldIDS):  ### 5-fold cross validation. We use randomly one fold as example
for foldID in range(foldIDS):
    start_time = time.time()   # count training time of each fold    
    
    print('Start fold ID:', foldID)
    
    # ----- path of result files of k-th fold ---------------------------------      
    save_dir = os.path.join(save_dir_group, str(foldID))  
    params['dir_name']       = save_dir
    
    Labelfile_fold   = os.path.join(save_dir , 'predict_test.csv')       
    Accfile_fold = os.path.join(save_dir, 'performance_test.csv')  
    Feature_fold = os.path.join(save_dir, 'feature.txt')  
    
    
    # ----- k-th fold training/validation/testing data and target real measures -------------
    print('Data splitting...')   
    TrainSet = fset[TrainSet_Kfold[0,foldID]][()].astype(int)[0] -1
    ValidSet = fset[ValidSet_Kfold[0,foldID]][()].astype(int)[0] -1  
    TestSet = fset[TestSet_Kfold[0,foldID]][()].astype(int)[0] -1

    data_train = data[TrainSet,:,:]
    data_valid = data[ValidSet,:,:]    
    data_test = data[TestSet,:,:]

    target_train = target[TrainSet]
    target_valid = target[ValidSet]    
    target_test =  target[TestSet]
    target_test0 = np.copy(target_test)


    ## ----- Z-score of real measures   --------------------------------------
    T_train = np.copy(target_train)
    T_valid = np.copy(target_valid)    
    T_test = np.copy(target_test)
    target_scaler = preprocessing.StandardScaler().fit(T_train.reshape(-1,1))
    target_train = target_scaler.transform(T_train.reshape(-1,1))[:,0]    
    
    target_valid = target_scaler.transform(T_valid.reshape(-1,1))[:,0]        
    target_test = target_scaler.transform(T_test.reshape(-1,1))[:,0]
    

    ## ----- remove mean and scale to unit variance at each node --------------
    # For each node, the mean and SD of fMRI across time and sujbects = 0 , 1
    n_train, T0, n0 = data_train.shape  #  (number of samples x number of time points x number of nodes)
    n_valid = data_valid.shape[0]    
    n_test = data_test.shape[0]    
#    
#    
    # ------- format data and target measures to float32 -------------------------------
    data_train = data_train.astype(np.float32)
    data_valid = data_valid.astype(np.float32)
    data_test = data_test.astype(np.float32)
    
    target_train = target_train.astype(np.float32)
    target_valid = target_valid.astype(np.float32)
    target_test  = target_test.astype(np.float32)
    
    print('Size of training set: ', data_train.shape)
    print('Size of validation set: ', data_valid.shape)
    print('Size of testing set: ', data_test.shape,'\n')   
    
          
    
    # ----- Training and validation -----------------------------------------------
    params['decay_steps']    = (np.multiply(decay_steps, n_train / params['batch_size'])).astype(int)
    model = models.FCCNN(T0, n0 , 1, **params)
        
    val_loss_list, val_mse_list,  val_mae_list,  val_corr_list, val_pval_list  = \
    model.fit(data_train, target_train, data_valid, target_valid, params['learning_rate'],params['num_epochs'],params['decay_steps'])
      

    #------training time---------------------------------------------
    fold_time = float(time.time() - start_time)
    Kfold_time = Kfold_time + fold_time
    format_str = 'training time of this fold: %.3f, epoch time this fold: %.3f'
    print (format_str % (fold_time, fold_time/params['num_epochs']),'\n') 
    
  
    # ----- Evaluate performance on testing set -----------------------------------
    # performace of Z-score of predicted measure
    res, test_loss, predictions, test_mse, test_mae, test_corr, test_pval, test_feature = model.evaluate(data_test, target_test)         
    test_rmse = np.sqrt(test_mse)
    test_corr2 = math.pow(test_corr, 2) 
    
    # save values and performance of Z-score of predicted measure   
    df = {'foldID':foldID,  'mse':test_mse, 'rmse':test_rmse, 'mae':test_mae, \
          'r': test_corr, 'pval':test_pval, 'r^2':test_corr2, \
          'whole time': fold_time,'epoch time': fold_time/params['num_epochs']}    
    df = pd.DataFrame(data=df, index=[0])
    df.to_csv(Accfile_fold.replace('.csv','_z.csv'), mode='a+', header=True) 
    df.to_csv(Accfile.replace('.csv','_z.csv'), mode='a+', header=(foldID==0))     
    df_predict = {'Idx':TestSet, 'Actual':target_test, 'Predicted':predictions}
    df_predict = pd.DataFrame(data=df_predict, dtype=np.float32)
    df_predict.to_csv(Labelfile_fold.replace('.csv','_z.csv'), mode='a+', header=True) 
    df_predict.to_csv(Labelfile.replace('.csv','_z.csv'), mode='a+', header=(foldID==0)) 
    
  #  f=open(Feature_fold,'a')
  #  for sub in range(0, n_test):
  #      np.savetxt(f, test_feature[sub,:] , fmt='%1.7f', delimiter=",", newline="; ")
  #      f.write("\n")
  #  f.close()
    
     # performace of predicted measure
    predictions0 = target_scaler.inverse_transform(predictions.reshape(-1,1))[:,0]
    test_mse = metrics.mean_squared_error(target_test0, predictions0)
    test_rmse = np.sqrt(test_mse)
    test_mae = metrics.mean_absolute_error(target_test0, predictions0)
    test_corr, test_pval = stats.pearsonr(target_test0, predictions0)
    test_corr2 = math.pow(test_corr, 2) 
    print('RMSE of test samples: ', str(test_rmse))
    print('MAE of test samples: ', str(test_mae))
    print('Pearson correlation of test samples: ', str(test_corr))
    print('P-value for Pearson correlation of test samples: ', str(test_pval))
    print('Coefficient of determination of test samples: ', str(test_corr2))
  
    # save values and performance of predicted measure
    df = {'foldID':foldID, 'mse':test_mse, 'rmse':test_rmse, 'mae':test_mae, \
          'r': test_corr, 'pval':test_pval, 'r^2':test_corr2,\
          'whole time': fold_time,'epoch time': fold_time/params['num_epochs']}   
    df = pd.DataFrame(data=df, index=[0])
    df.to_csv(Accfile_fold, mode='a+', header=True) 
    df.to_csv(Accfile, mode='a+', header=(foldID==0))         
    df_predict = {'Idx':TestSet, 'Actual':target_test0, 'Predicted':predictions0}
    df_predict = pd.DataFrame(data=df_predict, dtype=np.float32)
    df_predict.to_csv(Labelfile_fold, mode='a+', header=True) 
    df_predict.to_csv(Labelfile, mode='a+', header=(foldID==0)) 

    del model

fset.close()


# ----- Evaluate overall performance of K-fold cross-validation-----------------------------------
print('\n Overall performance:')

# read predicted values from all K folds    
V = pd.read_csv(Labelfile)
actual = np.array(V.Actual)
predictions = np.array(V.Predicted)

# evaluate overall performance
test_mse = metrics.mean_squared_error(actual, predictions)
test_rmse = np.sqrt(test_mse)
test_mae = metrics.mean_absolute_error(actual, predictions)
corr, pval = stats.pearsonr(actual, predictions)
corrsquare = math.pow(corr, 2) 
print('RMSE of test samples: ', str(test_rmse))
print('MAE of test samples: ', str(test_mae))
print('Pearson correlation of test samples: ', str(corr))
print('P-value for Pearson correlation of test samples: ', str(pval))
print('Coefficient of determination of test samples: ', str(corrsquare))

# overall training time
format_str = 'whole time: %.3f, epoch time: %.3f'
print (format_str % (Kfold_time, Kfold_time/params['num_epochs']/foldIDS))

# save the overall performance
df = {'aaidx':szDatetime0, 'mse':test_mse, 'rmse':test_rmse, 'mae':test_mae, 'r': corr, 'r^2':corrsquare, 'pval':pval,\
      'whole time': Kfold_time,'epoch time': Kfold_time/params['num_epochs']}   
df = pd.DataFrame(data=df, index=[0])
df.to_csv(Resultfile, mode='a+', header=True) 


