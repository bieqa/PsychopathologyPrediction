"""
Prediction of fluid intelligence (gF) via 5-fold (K=5) cross-validation on ABCD dataset 
using the "Functional connectivity convolutional (FC-conv) network", 
which is a major network of the "Spatio-Temporal Directed Acyclic Graph Learning 
with Attention Mechanisms (ST-DAG-Att)" framework

The FC-conv network includes
 - FC-conv:         Functional connectivity convolution
 - FC-SAtt:         Functional connectivity based spatial attention
 - Output layer:    multi-layer MLP

----------------------------------------------------------------
Input data:
./data/ABCD7693.mat: 
        'fMRI'      fMRI, number of all samples x number of time points x number of nodes
        'List'      List Sorting Working Memory,            number of all samples x 1
        'Pattern'   Pattern Comparison Processing Speed,    number of all samples x 1
        'Picture'   Picture SequenceMemory,                 number of all samples x 1
        'Flanker'   Flanker,                                number of all samples x 1
        'CardSort'  Dimensional Change Card Sort,           number of all samples x 1
         
./data/TrainValidTest_Idx_r?.mat: 
        'TrainSet'   K x 1 cell (consists of K arrays), training sample indices for K folds 
        'ValidSet'   K x 1 cell (consists of K arrays), validation sample indices for K folds
        'TestSet'    K x 1 cell (consists of K arrays), testing sample indices for K folds         
                            

----------------------------------------------------------------
Output results: 
./result/?/performance_Kfold.csv
        overall K-fold performance (correlation, MAE, RMSE, ... between real and predicted measures) 
  
./result/?/performance_test.csv: 
        K performances of K folds (correlation, MAE, RMSE, ... between real and predicted measures) 

./result/?/performance_test_z.csv: 
        K performances of K folds (correlation, MAE, RMSE, ... between Z-scores of real and predicted measures) 

./result/?/predict_test.csv: 
        real and predicted measures of all K folds
        
./result/?/predict_test_z.csv: 
        Z-scores of real and predicted measures of all K folds
        
./result/?/0 ~ K-1/:   Results of each fold, including
    performance_trainvalid.csv: training and validation performance 
    performance_test.csv:       testing performance
    performance_test_z.csv:     testing performance (Z-scores)    
    predict_test.csv:           real and predicted measures in testing set
    predict_test_z.csv:         real and predicted measures (Z-scores) in testing set
    other files:                saved models for future use (eg. transfer learning) 
----------------------------------------------------------------


May. 27, 2021  Created by Shih-Gu Huang

"""

from lib import model_FCconv_concate_2att_lr_mulscale_test as models

import numpy as np
from scipy import sparse, stats
from sklearn import preprocessing, metrics
import pandas as pd
import h5py
import math
import os
import time
import datetime


os.environ["CUDA_VISIBLE_DEVICES"]="0" 

run=1     # -th experiment
foldIDS=5   # number of folds


params = dict()
# ----- Architecture setting ----------------------------------------------------------
params['CeCn'] = [128, 256]     # number of filters of EdgeConv and NodeConv in FC-conv
params['r']    = 4              # bottleneck ratio in MLP in FC-SAtt 
params['M']    = [256, 128, 1]  # number of hidden nodes in fully-connected layers in output layer


# ----- Hyper-parameters ------------------------------------------------------


params['num_epochs']     = 0       # number of epochs
params['batch_size']     = 32       # batch size
params['learning_rate']  = 0.01    # initial learning rate
params['decay_rate']     = 1-0.05   # decay of learning rate
decay_steps   = 10                  # decay steps
params['momentum']       = 0.9      # momentum
params['dropout']        = 1.0-0.4  # keep_prob rate in dropout
params['regularization'] = 0.001    # regularization 
params['eval_frequency'] = 20       # number of iterations to display results on workspace  

# ----- data file names -------------------------------------------------------
DATADIR = '../data'                                 # data folder
Datafile='example20.mat'                             # fMRI data
Setfile='TrainValidTest_demo_Idx_r'+str(run)+'.mat'       # indices of training, validation, testing sets
SAVEDIR = 'result'                                  # result folder

# path of files 
path = os.path.dirname(os.path.realpath(__file__))
Datafile=os.path.join(path, DATADIR, Datafile)                
Setfile=os.path.join(path, DATADIR, Setfile)                


# ----- result folder and file names -----------------------------------------------------
szDatetime = datetime.datetime.now().strftime('%s')
szDatetime0 = szDatetime
szDatetime = 'PNC_gF_5fold_FCconv'  ### NOTE: replace the pretrained model!!
save_dir_group = os.path.join(path, SAVEDIR, szDatetime)               
Labelfile   = os.path.join(save_dir_group , 'predict_test.csv')          
Accfile = os.path.join(save_dir_group, 'performance_test.csv')        
Resultfile  = os.path.join(save_dir_group, 'performance_Kfold.csv')  


# ----- Load data and real measures --------------------------------------------------
print('Loading data ...')
f = h5py.File(Datafile, 'r')
print(list(f.keys()),'\n')

         
data = np.array(f.get('FC_conn')).astype(float)  
#data2 = np.array(f.get('Phen_noglo')).astype(float)  
        
Fear = np.array(f.get('Overall')).astype(float)[0]
  # Fluid IQ
target = Fear
#data = abs(data)
target = np.round(target, 1)
f.close()


# ----- Load indices of training, validation, testing sets --------------------
fset = h5py.File(Setfile, 'r')
TrainSet_Kfold = fset.get('TrainSet')
TestSet_Kfold = fset.get('TestSet')
ValidSet_Kfold = fset.get('ValidSet')

#target = np.around(target, 1)

Kfold_time = 0.0 # whole training time
# ----- K-fold cross-validation -----------------------------------------------  
for foldID in range(foldIDS): 
    start_time = time.time()   # count training time of each fold    
    
    print('Start fold ID:', foldID)
    
    # ----- path of result files of k-th fold ---------------------------------      
    save_dir = os.path.join(save_dir_group, str(foldID))  
    params['dir_name']       = save_dir
    
    Labelfile_fold   = os.path.join(save_dir , 'predict_test.csv')       
    Accfile_fold = os.path.join(save_dir, 'performance_test.csv')  
    Feature_fold = os.path.join(save_dir, 'feature.txt')
    Attention_fold = os.path.join(save_dir, 'att1.txt')
    Attention_fold2 = os.path.join(save_dir, 'att2.txt') 
    # ----- k-th fold training/validation/testing data and target real measures -------------
    print('Data splitting...')   
    TrainSet = fset[TrainSet_Kfold[0,foldID]][()].astype(int)[0] -1
    ValidSet = fset[ValidSet_Kfold[0,foldID]][()].astype(int)[0] -1  
    TestSet = fset[TestSet_Kfold[0,foldID]][()].astype(int)[0] -1
    TestSet = np.concatenate((TrainSet, ValidSet, TestSet),axis=0)   ####achieve selected features for all subjects

    data_train = data[TrainSet,:,:]
    data_valid = data[ValidSet,:,:]    
    data_test = data[TestSet,:,:]
    
    target_train = target[TrainSet]
    target_valid = target[ValidSet]    
    target_test =  target[TestSet]
    target_test0 = np.copy(target_test)


    ## ----- Z-score of real measures   --------------------------------------
    T_train = np.copy(target_train)
    T_valid = np.copy(target_valid)    
    T_test = np.copy(target_test)
    target_scaler = preprocessing.StandardScaler().fit(T_train.reshape(-1,1))
    target_train = target_scaler.transform(T_train.reshape(-1,1))[:,0]    
    
    target_valid = target_scaler.transform(T_valid.reshape(-1,1))[:,0]        
    target_test = target_scaler.transform(T_test.reshape(-1,1))[:,0]
    

    ## ----- remove mean and scale to unit variance at each node --------------
    # For each node, the mean and SD of fMRI across time and sujbects = 0 , 1
    n_train, T0, n0 = data_train.shape  #  (number of samples x number of time points x number of nodes)
    n_valid = data_valid.shape[0]    
    n_test = data_test.shape[0]    
#    
    # ------- format data and target measures to float32 -------------------------------
    data_train = data_train.astype(np.float32)
    data_valid = data_valid.astype(np.float32)
    data_test = data_test.astype(np.float32)
    
    target_train = target_train.astype(np.float32)
    target_valid = target_valid.astype(np.float32)
    target_test  = target_test.astype(np.float32)
    
    print('Size of training set: ', data_train.shape)
    print('Size of validation set: ', data_valid.shape)
    print('Size of testing set: ', data_test.shape,'\n')         
    
    # ----- Training and validation -----------------------------------------------
    params['decay_steps']    = (np.multiply(decay_steps, n_train / params['batch_size'])).astype(int)
    model = models.FCCNN(T0, n0 , 1, **params)
        
    
    model.fit( params['learning_rate'],params['num_epochs'],params['decay_steps'])
      

    #------training time---------------------------------------------
    fold_time = float(time.time() - start_time)
    Kfold_time = Kfold_time + fold_time
    format_str = 'training time of this fold: %.3f, epoch time this fold: %.3f'    
  
    # ----- Evaluate performance on testing set -----------------------------------
    # performace of Z-score of predicted measure
    res, test_loss, predictions, test_mse, test_mae, test_corr, test_pval, test_feature, test_att, test_att2 = model.evaluate(data_test, target_test)         
    test_rmse = np.sqrt(test_mse)
    test_corr2 = math.pow(test_corr, 2) 
    
    f=open(Feature_fold,'a')
    for sub in range(0, n_test):
        np.savetxt(f, test_feature[sub,:] , fmt='%1.7f', delimiter=",", newline="; ")
        f.write("\n")
    f.close()
    
    f=open(Attention_fold,'a')
    for sub in range(0, n_test):
        np.savetxt(f, test_att[sub, :] , fmt='%1.7f', delimiter=",", newline="; ")
        f.write("\n")
    f.close()
        
    f=open(Attention_fold2,'a')
    for sub in range(0, n_test):
        np.savetxt(f, test_att2[sub, :] , fmt='%1.7f', delimiter=",", newline="; ")
        f.write("\n")
    f.close()  

    del model

fset.close()




